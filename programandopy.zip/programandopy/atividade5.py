soma = 0

for numero in range(1,11):
    soma +=numero
print("a soma dos numeros e:", soma)