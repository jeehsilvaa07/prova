numeros = [1, 2, 3, 4, 5]
soma = 0
for numero in numeros:
    soma +=numero
print("a soma dos numeros e:", soma)
