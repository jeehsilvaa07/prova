frutas = ['maçã', 'banana', 'laranja']

for fruta in frutas:
    print("eu gosto de" , fruta)