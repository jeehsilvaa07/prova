for numero in range(1,11):
    print(numero) 